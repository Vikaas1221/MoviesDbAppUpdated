package com.example.moviesdbapp;

import com.example.moviesdbapp.Model.Trailers;

import java.util.ArrayList;

public interface id_interface
{
    public void item_id(String id,String type,String image);
}

package com.example.moviesdbapp;

public interface RecyclerViewClickListner
{
    void onItemClick(int position);
}

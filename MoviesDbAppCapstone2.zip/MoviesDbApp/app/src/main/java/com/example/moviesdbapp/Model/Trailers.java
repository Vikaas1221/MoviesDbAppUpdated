package com.example.moviesdbapp.Model;

public class Trailers
{
    String trailerKey;
    public Trailers(String trailerKey)
    {
        this.trailerKey=trailerKey;
    }
    public String getTrailerKey() {
        return trailerKey;
    }

    public void setTrailerKey(String trailerKey) {
        this.trailerKey = trailerKey;
    }



}

package com.example.moviesdbapp.Model;

import java.util.ArrayList;

public class movieurl
{
    public ArrayList<Trailers> arrayList;

    public ArrayList<Trailers> getArrayList()
    {
        return arrayList;
    }
    public void setArrayList(ArrayList<Trailers> arrayList) {

        this.arrayList = arrayList;
    }


}

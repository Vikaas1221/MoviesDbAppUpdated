public class Readme
{
    /*
    User guide
    In order to use this application you have to generate your own API key from themoviedb.org
    Then put that api key in the Movierepositry and then you can see the content

     */
}
